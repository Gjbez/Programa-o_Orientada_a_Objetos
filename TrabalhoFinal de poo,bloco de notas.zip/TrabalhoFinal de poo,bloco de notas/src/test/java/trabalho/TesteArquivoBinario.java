/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package trabalho;

import java.io.File;
import java.io.IOException;
import javax.swing.text.AttributeSet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author adriel, gustavo, guilherme
 */
public class TesteArquivoBinario {
    
    private Model model;
    private File tempFile;
    private ArquivoBinario arquivo;
    
    @Test
    public void testSaveFile() throws IOException {
    model = new Model();
    model.setText("Texto de teste");
    model.setAtributos(new AttributeSet[2]);
    model.setPosicaoText(10);

    tempFile = File.createTempFile("test", ".bin");
    arquivo = new ArquivoBinario(model);
    arquivo.saveFile(tempFile);

    assertTrue(tempFile.exists());
}
    @Test
    public void testOpenFile() throws IOException, ClassNotFoundException {
    model = new Model();
    model.setText("Texto inicial");
    model.setAtributos(new AttributeSet[1]);
    model.setPosicaoText(5);

    tempFile = File.createTempFile("test", ".bin");
    ArquivoBinario arquivo = new ArquivoBinario(model);
    arquivo.saveFile(tempFile);

    Model newModel = new Model();
    ArquivoBinario newArquivo = new ArquivoBinario(newModel);
    newArquivo.openFile(tempFile);

    assertEquals(model.getText(), newModel.getText());
    assertArrayEquals(model.getAtributos(), newModel.getAtributos());
    assertEquals(model.getPosicaoText(), newModel.getPosicaoText());
}
    @Test
    public void testSaveFileArquivoInexistente() {
    model = new Model();
    model.setText("Texto teste");
    arquivo = new ArquivoBinario(model);

    File invalidFile = new File("/path/invalido/arquivo.bin");
    assertDoesNotThrow(() -> arquivo.saveFile(invalidFile));
}
    @Test
    public void testIntegridadeDados() throws IOException, ClassNotFoundException {
    model = new Model();
    model.setText("Texto teste");
    model.setAtributos(new AttributeSet[0]);
    model.setPosicaoText(42);

    tempFile = File.createTempFile("test", ".bin");
    arquivo = new ArquivoBinario(model);
    arquivo.saveFile(tempFile);

    Model newModel = new Model();
    ArquivoBinario newArquivo = new ArquivoBinario(newModel);
    newArquivo.openFile(tempFile);

    assertEquals(model.getText(), newModel.getText());
    assertArrayEquals(model.getAtributos(), newModel.getAtributos());
    assertEquals(model.getPosicaoText(), newModel.getPosicaoText());
}

}
