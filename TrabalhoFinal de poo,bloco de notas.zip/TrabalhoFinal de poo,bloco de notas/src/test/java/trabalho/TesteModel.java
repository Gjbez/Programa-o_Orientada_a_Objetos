/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package trabalho;

import javax.swing.text.AttributeSet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author adriel, gustavo, guilherme
 */
public class TesteModel {
    
    private Model model;
    private AttributeSet[] expectedAttributes;
    
    @Test
    public void testSetText() {
    model = new Model();
    String expectedText = "Exemplo de texto";
    model.setText(expectedText);
    assertEquals(expectedText, model.getText());
}
    
    @Test
    public void testSetAtributos() {
    model = new Model();
    expectedAttributes = new AttributeSet[3];
    model.setAtributos(expectedAttributes);
    assertArrayEquals(expectedAttributes, model.getAtributos());
}
    @Test
    public void testSetPosicaoNegativa() {
    model = new Model();
    int expectedPosicao = -10;
    model.setPosicaoText(expectedPosicao);
    assertEquals(expectedPosicao, model.getPosicaoText());
}
    @Test
    public void testPersistenciaDadosAoAlterarTexto() {
     model = new Model();
    model.setText("Texto inicial");
    AttributeSet[] atributos = new AttributeSet[2];
    model.setAtributos(atributos);
    model.setPosicaoText(5);

    // Alterar o texto
    model.setText("Novo texto");

    // Verificar persistência
    assertEquals(atributos, model.getAtributos());
    assertEquals(5, model.getPosicaoText());
}   

}
