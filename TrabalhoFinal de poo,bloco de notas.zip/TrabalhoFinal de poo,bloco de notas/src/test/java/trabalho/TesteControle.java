package trabalho;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author adriel, gustavo, guilherme
 */
public class TesteControle {
    
    private JTextPane tpEscrita;
    private SimpleAttributeSet letrasGeral;
    private JFileChooser fcAbrirArquivo;
    private JFileChooser fcSalvarComo;
    private TelaPrincipal tela;
   
    @Test
    public void testInicializacao() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();
    tela = new TelaPrincipal(1);

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    assertNotNull(controle);
}
    
    @Test
    public void testInicializacaoTexto() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();
    tela = new TelaPrincipal(1);
    
    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    controle.inicializacaoTexto();
    assertEquals("", tpEscrita.getText());
}
    @Test
    public void testAbrirArquivoInvalido() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    tela = new TelaPrincipal(1);
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    assertThrows(IOException.class, () -> controle.abrirArquivo(1));
}
    @Test
    public void testCriarNovoArquivo() throws IOException, ClassNotFoundException, BadLocationException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    tela = new TelaPrincipal(1);
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    fcSalvarComo.setSelectedFile(new File("teste.poo"));
    controle.novoArquivo();

    assertEquals("", tpEscrita.getText());
}
    @Test
    public void testAplicarEstiloNegrito() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    tela = new TelaPrincipal(1);
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    controle.trataTipoTexto("Negrito");
    assertTrue(StyleConstants.isBold(letrasGeral));
}
    @Test
    public void testAlterarCorTexto() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    tela = new TelaPrincipal(1);
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    controle.trataCorTexto(Color.RED);
    assertEquals(Color.RED, controle.corTexto);
}
    @Test
    public void testAlterarCorMarcador() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    tela = new TelaPrincipal(1);
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    controle.trataCorMarcador(Color.YELLOW);
    assertEquals(Color.YELLOW, controle.corMarcador);
}
    @Test
    public void testAlinharEsquerda() throws BadLocationException, IOException, ClassNotFoundException {
    tpEscrita = new JTextPane();
    letrasGeral = new SimpleAttributeSet();
    tela = new TelaPrincipal(1);
    fcAbrirArquivo = new JFileChooser();
    fcSalvarComo = new JFileChooser();

    Controle controle = new Controle(tela, letrasGeral, tpEscrita, fcAbrirArquivo, fcSalvarComo);

    controle.alinharEsquerda();
    assertEquals(StyleConstants.ALIGN_LEFT, StyleConstants.getAlignment(letrasGeral));
}
    
}
